package javaproject;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.UIManager;

public class createaccount extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JTextField textField_3;
	private JTextField textField_4;
	private JPasswordField passwordField_1;
	private JTextField textField_5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		String jdbcURL = "jdbc:postgresql://localhost:5432/lab_6";
		String username = "postgres";
		String password = "Rkp@1801";
		
		try {
			Connection connection = DriverManager.getConnection(jdbcURL, username, password);
			
			System.out.print("Connected");
					}
			catch(SQLException e) {
				System.out.println("Error in connection");
				e.printStackTrace();
			}
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					createaccount frame = new createaccount();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public createaccount() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1248, 767);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Register");
		lblNewLabel.setFont(new Font("Baskerville Old Face", Font.BOLD, 39));
		lblNewLabel.setBounds(461, 42, 193, 43);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setFont(new Font("Bahnschrift", Font.PLAIN, 21));
		lblNewLabel_1.setBounds(91, 119, 160, 33);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Password");
		lblNewLabel_1_1.setFont(new Font("Bahnschrift", Font.PLAIN, 21));
		lblNewLabel_1_1.setBounds(91, 308, 138, 33);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Phone.No");
		lblNewLabel_1_2.setFont(new Font("Bahnschrift", Font.PLAIN, 21));
		lblNewLabel_1_2.setBounds(91, 400, 127, 33);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Email");
		lblNewLabel_1_3.setFont(new Font("Bahnschrift", Font.PLAIN, 21));
		lblNewLabel_1_3.setBounds(91, 509, 108, 33);
		contentPane.add(lblNewLabel_1_3);
		
		textField = new JTextField();
		textField.setBounds(261, 119, 223, 33);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(255, 400, 223, 33);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(777, 400, 223, 33);
		contentPane.add(textField_2);
		
		JButton btnNewButton = new JButton("CREATE");
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setBackground(Color.LIGHT_GRAY);
		btnNewButton.setFont(new Font("Verdana", Font.BOLD, 18));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnNewButton.setBounds(456, 670, 133, 33);
		contentPane.add(btnNewButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Customer");
		rdbtnNewRadioButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		buttonGroup.add(rdbtnNewRadioButton_1);
		rdbtnNewRadioButton_1.setBounds(340, 576, 103, 21);
		contentPane.add(rdbtnNewRadioButton_1);
		
		JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Owner");
		rdbtnNewRadioButton_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		buttonGroup.add(rdbtnNewRadioButton_2);
		rdbtnNewRadioButton_2.setBounds(610, 576, 103, 21);
		contentPane.add(rdbtnNewRadioButton_2);
		
		JButton btnNewButton_1 = new JButton(" Return");
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loginpage logpg = new loginpage();
				logpg.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(1067, 656, 95, 33);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_2 = new JLabel("First Name");
		lblNewLabel_2.setFont(new Font("Bahnschrift", Font.PLAIN, 21));
		lblNewLabel_2.setBounds(96, 208, 122, 33);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("Last Name");
		lblNewLabel_2_1.setFont(new Font("Bahnschrift", Font.PLAIN, 21));
		lblNewLabel_2_1.setBounds(610, 208, 122, 33);
		contentPane.add(lblNewLabel_2_1);
		
		textField_3 = new JTextField();
		textField_3.setBounds(255, 208, 223, 33);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(777, 208, 223, 33);
		contentPane.add(textField_4);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(255, 308, 225, 33);
		contentPane.add(passwordField_1);
		
		JLabel lblNewLabel_1_2_1 = new JLabel("Phone.No");
		lblNewLabel_1_2_1.setFont(new Font("Bahnschrift", Font.PLAIN, 21));
		lblNewLabel_1_2_1.setBounds(610, 400, 127, 33);
		contentPane.add(lblNewLabel_1_2_1);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(255, 509, 223, 33);
		contentPane.add(textField_5);
	}
}
