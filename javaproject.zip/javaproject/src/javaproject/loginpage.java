package javaproject;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class loginpage extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField user_name;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		String jdbcURL = "jdbc:postgresql://localhost:5432/lab_6";
		String username = "postgres";
		String password = "Rkp@1801";
		
		try {
			Connection connection = DriverManager.getConnection(jdbcURL, username, password);
			
			System.out.print("Connected");
					}
			catch(SQLException e) {
				System.out.println("Error in connection");
				e.printStackTrace();
			}
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					loginpage frame = new loginpage();
					frame.setResizable(false);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public loginpage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 631, 537);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(0, 0, 139));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("BACKWATER TRIPS");
		lblNewLabel.setBackground(new Color(255, 228, 196));
		lblNewLabel.setForeground(new Color(0, 0, 128));
		lblNewLabel.setFont(new Font("MV Boli", Font.BOLD, 32));
		lblNewLabel.setBounds(174, 33, 346, 66);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("USERNAME");
		lblNewLabel_2.setBackground(new Color(0, 0, 205));
		lblNewLabel_2.setForeground(new Color(0, 0, 0));
		lblNewLabel_2.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 22));
		lblNewLabel_2.setBounds(127, 200, 186, 50);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("PASSWORD");
		lblNewLabel_2_1.setForeground(new Color(128, 0, 0));
		lblNewLabel_2_1.setFont(new Font("Tw Cen MT Condensed Extra Bold", Font.PLAIN, 22));
		lblNewLabel_2_1.setBounds(127, 260, 186, 50);
		contentPane.add(lblNewLabel_2_1);
		
		textField = new JTextField();
		textField.setBounds(228, 186, 85, -16);
		contentPane.add(textField);
		textField.setColumns(10);
		
		user_name = new JTextField();
		user_name.setBackground(new Color(245, 245, 220));
		user_name.setBounds(294, 205, 226, 36);
		contentPane.add(user_name);
		user_name.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setForeground(new Color(0, 0, 0));
		passwordField.setBackground(new Color(245, 245, 220));
		passwordField.setBounds(295, 268, 225, 36);
		contentPane.add(passwordField);
		
		JButton btnNewButton = new JButton("Login\r\n");
		btnNewButton.setBackground(new Color(255, 140, 0));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setFont(new Font("Swis721 BlkEx BT", Font.PLAIN, 17));
		btnNewButton.setBounds(228, 338, 128, 36);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Create Account");
		btnNewButton_1.setBackground(new Color(255, 140, 0));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				createaccount accpage = new createaccount();
				accpage.setVisible(true);
				dispose();
				
			}
		});
		btnNewButton_1.setFont(new Font("Swis721 Ex BT", Font.BOLD, 13));
		btnNewButton_1.setBounds(406, 417, 165, 30);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setIcon(new ImageIcon("D:\\RKP\\3rd Sem\\Eclipse\\javaproject\\boatlogo.jpg"));
		lblNewLabel_1.setBounds(0, 12, 170, 123);
		contentPane.add(lblNewLabel_1);
	}

}
